# Taskbar groups
Lightweight application that lets user create and pin groups to the Windows taskbar och desktop
<br>
<br>
Preview of a taskbar group:
<br>
![Preview of taskbar group](https://i.imgur.com/PDgofAp.png)
<br><br>
Preview of client:
<br>
![Preview of client](https://i.imgur.com/WFdqcot.png)
<br><br>
Also works on desktop shortcuts:
<br>
![Also works on desktop shortcuts](https://i.imgur.com/M3KKJe0.png)
