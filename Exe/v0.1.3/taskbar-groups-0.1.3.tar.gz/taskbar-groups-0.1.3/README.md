# taskbar-groups
Easy access groups in windows taskbar
<br>
<br>
Preview of a taskbar group:
<br>
![Preview of taskbar group](https://i.imgur.com/aw4aBML.png)
<br><br>
Preview of client:
<br>
![Preview of client](https://i.imgur.com/t0tUUnE.png)
<br><br>
Also works on desktop shortcuts:
<br>
![Also works on desktop shortcuts](https://i.imgur.com/qHS2WUG.png)
